export default function BookCard({ book, dark }) {
  const cover = book.cover_i
    ? `https://covers.openlibrary.org/b/id/${book.cover_i}-M.jpg`
    : "https://dummyimage.com/128x192/eeeeee/aaaaaa&text=No+Cover";

  const authors = book.author_name?.join(", ") ?? "Unknown author";

  return (
    <article className={`flex gap-4 p-4 rounded-2xl border 
                        bg-white dark:bg-slate-800 shadow-sm hover:shadow-md transition
                        border-gray-200 dark:border-gray-700`}>
      <img
        src={cover}
        alt={`${book.title} cover`}
        className="w-24 h-36 object-cover rounded-md border border-gray-300 dark:border-gray-600"
        loading="lazy"
      />
      <div className="flex-1 text-black dark:text-white">
        <h3 className="font-semibold text-lg leading-snug">{book.title}</h3>
        <p className="text-sm text-gray-700 dark:text-gray-300 mt-1">{authors}</p>
        <div className="text-xs text-gray-500 dark:text-gray-400 mt-2 flex flex-wrap gap-x-4 gap-y-1">
          {book.first_publish_year && <span>First published: {book.first_publish_year}</span>}
          {book.language?.length && <span>Lang: {book.language.slice(0, 3).join(", ")}</span>}
          {typeof book.edition_count === "number" && <span>Editions: {book.edition_count}</span>}
        </div>
        <div className="mt-3 text-sm">
          {book.key && (
            <a
              className="underline text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-200"
              href={`https://openlibrary.org${book.key}`}
              target="_blank"
              rel="noreferrer"
            >
              View on Open Library →
            </a>
          )}
        </div>
      </div>
    </article>
  );
}
