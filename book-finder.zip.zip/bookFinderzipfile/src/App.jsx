import React, { useEffect, useMemo, useState } from "react";
import BookCard from "./BookCard";

const BASE_URL = "https://openlibrary.org/search.json";

export default function App() {
  const [dark, setDark] = useState(false); // light mode default
  const [query, setQuery] = useState("");
  const [year, setYear] = useState("");
  const [ebookOnly, setEbookOnly] = useState(false);

  const [books, setBooks] = useState([]);
  const [numFound, setNumFound] = useState(0);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    document.documentElement.classList.toggle("dark", dark);
    localStorage.setItem("theme", dark ? "dark" : "light");
  }, [dark]);

  // Only include title and page in API URL
  const url = useMemo(() => {
    const params = new URLSearchParams();
    if (query.trim()) params.set("title", query.trim());
    params.set("page", String(page));
    return `${BASE_URL}?${params.toString()}`;
  }, [query, page]);

  async function fetchBooks(signal) {
    if (!query.trim()) {
      setBooks([]);
      setNumFound(0);
      return;
    }

    try {
      setLoading(true);
      setError("");
      const opts = signal ? { signal } : {};
      const res = await fetch(url, opts);
      if (!res.ok) throw new Error(`Network error: ${res.status}`);
      const data = await res.json();
      let docs = data.docs ?? [];

      // Filter ebookOnly client-side
      if (ebookOnly)
        docs = docs.filter((d) => d.ebook_access && d.ebook_access !== "no_ebook");

      // Filter by year client-side
      if (year.trim())
        docs = docs.filter((d) => d.first_publish_year >= Number(year));

      setBooks(docs);
      setNumFound(data.numFound ?? docs.length);
    } catch (e) {
      if (e.name !== "AbortError") setError(e.message || "Something went wrong");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    if (!query.trim()) return;
    const controller = new AbortController();
    const t = setTimeout(() => fetchBooks(controller.signal), 350);
    return () => {
      controller.abort();
      clearTimeout(t);
    };
  }, [url, ebookOnly, year]);

  function onSubmit(e) {
    e?.preventDefault();
    setPage(1);
    fetchBooks();
  }

  // Calculate total pages based on API result count
  const totalPages = Math.ceil(numFound / 100);

  return (
    <div className="min-h-screen py-10 px-4 bg-gray-100 dark:bg-gray-900 transition-colors">
      <div className="max-w-4xl mx-auto">
        {/* Navbar */}
        <header className="mb-8 p-6 rounded-3xl shadow-lg flex items-center justify-between gap-4
                           bg-gradient-to-r from-indigo-500 to-purple-600
                           dark:bg-gradient-to-r dark:from-gray-800 dark:to-slate-900
                           text-white">
          <h1 className="text-3xl font-extrabold">📚 Book Finder</h1>

          <button
            onClick={() => setDark((d) => !d)}
            className={`px-3 py-2 rounded-lg bg-white/20 hover:bg-white/30 transition font-semibold ${
              !dark ? "text-white" : "text-gray-200"
            }`}
            title="Toggle theme"
          >
            {dark ? "🌙 Dark" : "☀️ Light"}
          </button>
        </header>

        {/* Search panel */}
        <form onSubmit={onSubmit} className="grid gap-4 mb-2">
          <div className="flex gap-3">
            <label className="flex-1 relative">
              <input
                className="w-full rounded-2xl border p-3 pl-12
                           bg-white dark:bg-slate-900 text-black dark:text-white
                           placeholder-gray-400 dark:placeholder-gray-500
                           input-focus focus:ring-2 focus:ring-purple-500"
                type="text"
                placeholder="Search title"
                value={query}
                onChange={(e) => {
                  setQuery(e.target.value);
                  setPage(1);
                }}
              />
              <svg
                className="w-5 h-5 absolute left-4 top-3.5 text-slate-400 dark:text-slate-500"
                viewBox="0 0 20 20"
                fill="currentColor"
                aria-hidden
              >
                <path
                  fillRule="evenodd"
                  d="M12.9 14.32a7 7 0 111.414-1.414l3.387 3.387a1 1 0 01-1.414 1.414l-3.387-3.387zM14 8a6 6 0 11-12 0 6 6 0 0112 0z"
                  clipRule="evenodd"
                />
              </svg>
            </label>

            <button
              type="submit"
              className="px-5 py-3 rounded-2xl bg-gradient-to-r from-indigo-500 to-purple-600 text-white font-semibold hover:scale-[0.99] transition"
            >
              🔎 Search
            </button>
          </div>

          <div className="grid sm:grid-cols-3 gap-3">
            <input
              className="rounded-xl border p-2.5
                         bg-white dark:bg-slate-900 text-black dark:text-white
                         placeholder-gray-400 dark:placeholder-gray-500
                         input-focus focus:ring-2 focus:ring-purple-500"
              type="number"
              min="0"
              placeholder="First publish year (optional)"
              value={year}
              onChange={(e) => {
                setYear(e.target.value);
                setPage(1);
              }}
            />

            <label className="inline-flex items-center gap-2">
              <input
                type="checkbox"
                checked={ebookOnly}
                onChange={(e) => {
                  setEbookOnly(e.target.checked);
                  setPage(1);
                }}
                className="accent-indigo-500 w-4 h-4"
              />
              <span className="text-sm text-slate-600 dark:text-slate-300">
                Show eBooks only
              </span>
            </label>

            <div></div> {/* empty for alignment */}
          </div>
        </form>

        {/* Results info */}
        {query && !loading && !error && (
          <div className="mb-4 text-sm text-slate-600 dark:text-slate-300">
            {numFound.toLocaleString()} results — page {page} of {totalPages}
          </div>
        )}

        {/* Status / errors */}
        {error && (
          <div className="mb-4 p-3 rounded-lg bg-red-50 dark:bg-red-900 text-red-700 dark:text-red-300 border border-red-100 dark:border-red-700">
            {error}
          </div>
        )}

        {/* Loading skeleton */}
        {loading && (
          <div className="space-y-4">
            {Array.from({ length: 4 }).map((_, i) => (
              <div
                key={i}
                className="p-4 rounded-2xl bg-white dark:bg-slate-800 shadow animate-pulse h-28"
              />
            ))}
          </div>
        )}

        {/* No results */}
        {!loading && !error && query && books.length === 0 && (
          <div className="p-6 rounded-2xl bg-white dark:bg-slate-800 shadow text-center text-slate-600 dark:text-slate-300">
            <div className="text-lg font-medium">No results found</div>
            <div className="text-sm mt-1">Try a different title or remove filters</div>
          </div>
        )}

        {/* Results */}
        <section className="mt-4 space-y-4">
          {books.map((b, i) => (
            <BookCard key={`${b.key}-${i}`} book={b} dark={dark} />
          ))}
        </section>

        {/* Pagination */}
        <div className="mt-6 flex items-center justify-center gap-3">
          <button
            disabled={page <= 1}
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            className="px-4 py-2 rounded-full bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 disabled:opacity-40 transition"
          >
            ← Prev
          </button>

          <div className="text-sm text-slate-600 dark:text-slate-300">
            Page {page} of {totalPages}
          </div>

          <button
            disabled={page >= totalPages}
            onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
            className="px-4 py-2 rounded-full bg-indigo-500 text-white disabled:opacity-40 transition"
          >
            Next →
          </button>
        </div>

        <footer className="mt-8 text-xs text-center text-slate-500 dark:text-slate-400">
          Data from Open Library —{" "}
          <a
            className="underline"
            href="https://openlibrary.org/dev/docs/api/search"
            target="_blank"
            rel="noreferrer"
          >
            API docs
          </a>
        </footer>
      </div>
    </div>
  );
}
