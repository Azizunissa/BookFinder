# Book Finder (Vite + React + Tailwind)

## Setup
1. npm install
2. npm run dev
3. Open the printed URL (usually http://localhost:5173)

If styling looks plain:
- Make sure `src/index.css` is imported in `src/main.jsx`.
- Ensure the dev server is running (`npm run dev`) and your browser didn't load a cached page.
- Remove any old Tailwind CDN script from index.html (we use PostCSS setup).
